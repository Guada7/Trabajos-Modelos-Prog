/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Personaje;

/**
 *
 * @author Estudiantes
 */
public class Hermione extends Personaje {
    
    public Hermione (){
        super("Hermione Granger");
    }
    
    @Override
    public void lanzarHechizo() {
        hechizo.lanzarHechizo();
    }
    
}
